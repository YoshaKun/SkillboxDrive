//
//  dffhgeb.swift
//  SkillboxDrive
//
//  Created by Yosha Kun on 12.10.2023.
//

import UIKit

final class LoginScreenModel {
    
    let constant = Constants.self
    
}
